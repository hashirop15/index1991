export default function GlobalActivityCard() {
  return (
    <div>
      
    </div>
  )
}
