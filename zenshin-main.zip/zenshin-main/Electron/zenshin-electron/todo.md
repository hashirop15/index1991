# TODO
- AniList updation conditional rendering
- Make filtering anilist user list better
- Add filter for genre in user anilist
- Allow settings to be reset
- Announce torrent
