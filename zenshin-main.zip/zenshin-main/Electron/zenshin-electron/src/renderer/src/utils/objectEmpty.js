// Object.keys(yourObject).length

export function isObjectEmpty(obj) {
  return Object.keys(obj).length === 0
}
