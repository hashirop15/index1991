function CassetteTapeLogo({ style = '' }) {
  return (
    <div className={style !== '' ? `${style}` : `flex h-6 w-6 items-center justify-center`}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="21"
        height="21"
        className="fill-current"
        viewBox="0 0 256 256"
      >
        <path d="M224,48H32A16,16,0,0,0,16,64V192a16,16,0,0,0,16,16H224a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM80,192l12-16h72l12,16Zm144,0H196l-21.6-28.8A8,8,0,0,0,168,160H88a8,8,0,0,0-6.4,3.2L60,192H32V64H224V192ZM176,80H80a32,32,0,0,0,0,64h96a32,32,0,0,0,0-64ZM148.3,96a31.92,31.92,0,0,0,0,32H107.7a31.92,31.92,0,0,0,0-32ZM64,112a16,16,0,1,1,16,16A16,16,0,0,1,64,112Zm112,16a16,16,0,1,1,16-16A16,16,0,0,1,176,128Z"></path>
      </svg>
    </div>
  )
}

export default CassetteTapeLogo
